﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using project_zh.Models;

namespace project_zh
{
    public partial class UserControl2 : UserControl
    {
        DartsDbContext context = new DartsDbContext();

        public UserControl2()
        {
            InitializeComponent();
            LoadData();
            button1.Click += Button1_Click;
        }

        private void LoadData()
        {
            context.Matches.Load();
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = context.Matches.Local.ToBindingList();

            dataGridView1.DataSource = bindingSource;
            AddComboBoxColumn("Player1_Name", "1. Játékos", "Player1ID");
            AddComboBoxColumn("Player2_Name", "2. Játékos", "Player2ID");
            AddComboBoxColumn("Winner_Name", "Győztes", "WinnerID");
            foreach (DataGridViewColumn col in dataGridView1.Columns)
            {
                col.Visible = false;
            }
            if (dataGridView1.Columns["MatchDate"] != null)
            {
                dataGridView1.Columns["MatchDate"].Visible = true;
                dataGridView1.Columns["MatchDate"].HeaderText = "Dátum";
                dataGridView1.Columns["MatchDate"].DefaultCellStyle.Format = "yyyy.MM.dd"; 
            }
            if (dataGridView1.Columns["MatchVenue"] != null)
            {
                dataGridView1.Columns["MatchVenue"].Visible = true;
                dataGridView1.Columns["MatchVenue"].HeaderText = "Helyszín";
            }

            if (dataGridView1.Columns["Spectators"] != null)
            {
                dataGridView1.Columns["Spectators"].Visible = true;
                dataGridView1.Columns["Spectators"].HeaderText = "Nézőszám";
            }

            if (dataGridView1.Columns["Player1_Name"] != null) dataGridView1.Columns["Player1_Name"].Visible = true;
            if (dataGridView1.Columns["Player2_Name"] != null) dataGridView1.Columns["Player2_Name"].Visible = true;
            if (dataGridView1.Columns["Winner_Name"] != null) dataGridView1.Columns["Winner_Name"].Visible = true;

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
        }
        private void AddComboBoxColumn(string colName, string headerText, string dataPropertyName)
        {
            if (dataGridView1.Columns.Contains(colName)) return;

            DataGridViewComboBoxColumn cmb = new DataGridViewComboBoxColumn();
            cmb.HeaderText = headerText;
            cmb.Name = colName;
            cmb.DataSource = context.Players.ToList();
            cmb.DisplayMember = "FirstName"; 
            cmb.ValueMember = "PlayerID";    

            cmb.DataPropertyName = dataPropertyName;

            dataGridView1.Columns.Add(cmb);
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;
            if (MessageBox.Show("Biztosan törölni akarod a kijelölt meccset?", "Törlés", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    Match matchToDelete = (Match)dataGridView1.CurrentRow.DataBoundItem;

                    var statsToDelete = context.PlayerMatchStats
                                               .Where(s => s.MatchId == matchToDelete.MatchId)
                                               .ToList();
                    if (statsToDelete.Any())
                    {
                        context.PlayerMatchStats.RemoveRange(statsToDelete);
                    }
                    context.Matches.Remove(matchToDelete);
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hiba történt: \n" + ex.Message +
                                    "\n\nRészletek: " + (ex.InnerException != null ? ex.InnerException.Message : ""));
                }
            }
        }
    }
}