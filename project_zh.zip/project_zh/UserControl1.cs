﻿using System;
using System.Linq;
using System.Windows.Forms;
using project_zh.Models;
using Microsoft.EntityFrameworkCore;
using System.Xml.Linq;

namespace project_zh
{
    public partial class UserControl1 : UserControl
    {

        private DartsDbContext context = new DartsDbContext();

        public UserControl1()
        {
            InitializeComponent();
            LoadData();
            textBox1.TextChanged += TxtSearch_TextChanged;
        }

        private void LoadData()
        {
            var players = context.Players.OrderBy(x => x.FirstName).ToList();

            listBox1.DataSource = players;
            listBox1.DisplayMember = "FirstName";

            textBox2.DataBindings.Add("Text", players, "FirstName");
            textBox3.DataBindings.Add("Text", players, "Country");
            textBox4.DataBindings.Add("Text", players, "PlayerId");
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            string filter = textBox1.Text.ToLower();

            var filteredPlayers = context.Players
                .Where(p => p.FirstName.ToLower().Contains(filter))
                .OrderBy(x => x.FirstName)
                .ToList();

            listBox1.DataSource = filteredPlayers;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "XML fájl|*.xml";
            sfd.FileName = "jatekosok.xml";
            sfd.Title = "Játékosok listájának mentése";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    var players = context.Players.OrderBy(p => p.FirstName).ToList();

                    XDocument xdoc = new XDocument(
                        new XElement("DartsDatabase",
                            new XElement("ExportDate", DateTime.Now.ToString()),
                            new XElement("PlayersList",
                                from p in players
                                select new XElement("Player",
                                    new XAttribute("ID", p.PlayerId),
                                    new XElement("Name", p.FirstName + " " + p.LastName),
                                    new XElement("Details",
                                        new XElement("Country", p.Country)
                                    )
                                )
                            )
                        )
                    );
                    xdoc.Save(sfd.FileName);

                    MessageBox.Show("Sikeres XML exportálás!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hiba történt az exportálás közben: \n" + ex.Message, "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}