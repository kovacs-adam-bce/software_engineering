﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace project_zh.Models;

[Keyless]
[Table("MSSQL_LedgerHistoryFor_2021582240")]
public partial class MssqlLedgerHistoryFor2021582240
{
    [Column("StatID")]
    public int StatId { get; set; }

    [Column("MatchID")]
    public int MatchId { get; set; }

    [Column("PlayerID")]
    public int PlayerId { get; set; }

    [Column(TypeName = "decimal(5, 2)")]
    public decimal? ThreeDartAverage { get; set; }

    [Column(TypeName = "decimal(4, 1)")]
    public decimal? CheckoutPercentage { get; set; }

    public int? Total180s { get; set; }

    public int? LegsWon { get; set; }

    [Column("ledger_start_transaction_id")]
    public long LedgerStartTransactionId { get; set; }

    [Column("ledger_end_transaction_id")]
    public long? LedgerEndTransactionId { get; set; }

    [Column("ledger_start_sequence_number")]
    public long LedgerStartSequenceNumber { get; set; }

    [Column("ledger_end_sequence_number")]
    public long? LedgerEndSequenceNumber { get; set; }
}
