﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace project_zh.Models;

[Keyless]
[Table("MSSQL_LedgerHistoryFor_1845581613")]
public partial class MssqlLedgerHistoryFor1845581613
{
    [Column("PlayerID")]
    public int PlayerId { get; set; }

    [StringLength(50)]
    public string FirstName { get; set; } = null!;

    [StringLength(50)]
    public string LastName { get; set; } = null!;

    [StringLength(50)]
    public string? Country { get; set; }

    [Column("ledger_start_transaction_id")]
    public long LedgerStartTransactionId { get; set; }

    [Column("ledger_end_transaction_id")]
    public long? LedgerEndTransactionId { get; set; }

    [Column("ledger_start_sequence_number")]
    public long LedgerStartSequenceNumber { get; set; }

    [Column("ledger_end_sequence_number")]
    public long? LedgerEndSequenceNumber { get; set; }
}
