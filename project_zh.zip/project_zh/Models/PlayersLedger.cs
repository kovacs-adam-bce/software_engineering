﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace project_zh.Models;

[Keyless]
public partial class PlayersLedger
{
    [Column("PlayerID")]
    public int PlayerId { get; set; }

    [StringLength(50)]
    public string FirstName { get; set; } = null!;

    [StringLength(50)]
    public string LastName { get; set; } = null!;

    [StringLength(50)]
    public string? Country { get; set; }

    [Column("ledger_transaction_id")]
    public long? LedgerTransactionId { get; set; }

    [Column("ledger_sequence_number")]
    public long? LedgerSequenceNumber { get; set; }

    [Column("ledger_operation_type")]
    public int LedgerOperationType { get; set; }

    [Column("ledger_operation_type_desc")]
    [StringLength(6)]
    public string LedgerOperationTypeDesc { get; set; } = null!;
}
