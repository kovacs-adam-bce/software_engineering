﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace project_zh.Models;

[Keyless]
public partial class PlayerMatchStatsLedger
{
    [Column("StatID")]
    public int StatId { get; set; }

    [Column("MatchID")]
    public int MatchId { get; set; }

    [Column("PlayerID")]
    public int PlayerId { get; set; }

    [Column(TypeName = "decimal(5, 2)")]
    public decimal? ThreeDartAverage { get; set; }

    [Column(TypeName = "decimal(4, 1)")]
    public decimal? CheckoutPercentage { get; set; }

    public int? Total180s { get; set; }

    public int? LegsWon { get; set; }

    [Column("ledger_transaction_id")]
    public long? LedgerTransactionId { get; set; }

    [Column("ledger_sequence_number")]
    public long? LedgerSequenceNumber { get; set; }

    [Column("ledger_operation_type")]
    public int LedgerOperationType { get; set; }

    [Column("ledger_operation_type_desc")]
    [StringLength(6)]
    public string LedgerOperationTypeDesc { get; set; } = null!;
}
