﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace project_zh.Models;

[Table("MATCHES")]
public partial class Match
{
    [Key]
    [Column("MatchID")]
    public int MatchId { get; set; }

    public DateOnly MatchDate { get; set; }

    [StringLength(50)]
    public string? MatchVenue { get; set; }

    public int? Spectators { get; set; }

    [Column("WinnerID")]
    public int? WinnerId { get; set; }

    [Column("Player1_ID")]
    public int Player1Id { get; set; }

    [Column("Player2_ID")]
    public int Player2Id { get; set; }

    [ForeignKey("Player1Id")]
    [InverseProperty("MatchPlayer1s")]
    public virtual Player Player1 { get; set; } = null!;

    [ForeignKey("Player2Id")]
    [InverseProperty("MatchPlayer2s")]
    public virtual Player Player2 { get; set; } = null!;

    [InverseProperty("Match")]
    public virtual ICollection<PlayerMatchStat> PlayerMatchStats { get; set; } = new List<PlayerMatchStat>();

    [ForeignKey("WinnerId")]
    [InverseProperty("MatchWinners")]
    public virtual Player? Winner { get; set; }
}
