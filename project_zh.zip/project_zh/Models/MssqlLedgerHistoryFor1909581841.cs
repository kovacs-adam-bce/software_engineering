﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace project_zh.Models;

[Keyless]
[Table("MSSQL_LedgerHistoryFor_1909581841")]
public partial class MssqlLedgerHistoryFor1909581841
{
    [Column("MatchID")]
    public int MatchId { get; set; }

    public DateOnly MatchDate { get; set; }

    [StringLength(50)]
    public string? MatchVenue { get; set; }

    public int? Spectators { get; set; }

    [Column("WinnerID")]
    public int? WinnerId { get; set; }

    [Column("Player1_ID")]
    public int Player1Id { get; set; }

    [Column("Player2_ID")]
    public int Player2Id { get; set; }

    [Column("ledger_start_transaction_id")]
    public long LedgerStartTransactionId { get; set; }

    [Column("ledger_end_transaction_id")]
    public long? LedgerEndTransactionId { get; set; }

    [Column("ledger_start_sequence_number")]
    public long LedgerStartSequenceNumber { get; set; }

    [Column("ledger_end_sequence_number")]
    public long? LedgerEndSequenceNumber { get; set; }
}
