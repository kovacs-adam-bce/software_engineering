﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace project_zh.Models;

[Keyless]
public partial class MatchesLedger
{
    [Column("MatchID")]
    public int MatchId { get; set; }

    public DateOnly MatchDate { get; set; }

    [StringLength(50)]
    public string? MatchVenue { get; set; }

    public int? Spectators { get; set; }

    [Column("WinnerID")]
    public int? WinnerId { get; set; }

    [Column("Player1_ID")]
    public int Player1Id { get; set; }

    [Column("Player2_ID")]
    public int Player2Id { get; set; }

    [Column("ledger_transaction_id")]
    public long? LedgerTransactionId { get; set; }

    [Column("ledger_sequence_number")]
    public long? LedgerSequenceNumber { get; set; }

    [Column("ledger_operation_type")]
    public int LedgerOperationType { get; set; }

    [Column("ledger_operation_type_desc")]
    [StringLength(6)]
    public string LedgerOperationTypeDesc { get; set; } = null!;
}
