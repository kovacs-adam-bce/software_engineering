﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace project_zh.Models;

public partial class DartsDbContext : DbContext
{
    public DartsDbContext()
    {
    }

    public DartsDbContext(DbContextOptions<DartsDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Match> Matches { get; set; }

    public virtual DbSet<MatchesLedger> MatchesLedgers { get; set; }

    public virtual DbSet<MssqlLedgerHistoryFor1845581613> MssqlLedgerHistoryFor1845581613s { get; set; }

    public virtual DbSet<MssqlLedgerHistoryFor1909581841> MssqlLedgerHistoryFor1909581841s { get; set; }

    public virtual DbSet<MssqlLedgerHistoryFor2021582240> MssqlLedgerHistoryFor2021582240s { get; set; }

    public virtual DbSet<Player> Players { get; set; }

    public virtual DbSet<PlayerMatchStat> PlayerMatchStats { get; set; }

    public virtual DbSet<PlayerMatchStatsLedger> PlayerMatchStatsLedgers { get; set; }

    public virtual DbSet<PlayersLedger> PlayersLedgers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=tcp:liverpool.database.windows.net,1433;Initial Catalog=my_sql_database;Persist Security Info=False;User ID=fd0mr8;Password=Husika@1119;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=True;Connection Timeout=30");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Match>(entity =>
        {
            entity.HasKey(e => e.MatchId).HasName("PK__MATCHES__4218C83739F30F48");

            entity.Property(e => e.MatchId).ValueGeneratedNever();

            entity.HasOne(d => d.Player1).WithMany(p => p.MatchPlayer1s)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__MATCHES__Player1__73BA3083");

            entity.HasOne(d => d.Player2).WithMany(p => p.MatchPlayer2s)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__MATCHES__Player2__74AE54BC");

            entity.HasOne(d => d.Winner).WithMany(p => p.MatchWinners).HasConstraintName("FK__MATCHES__WinnerI__75A278F5");
        });

        modelBuilder.Entity<MatchesLedger>(entity =>
        {
            entity.ToView("MATCHES_Ledger");
        });

        modelBuilder.Entity<Player>(entity =>
        {
            entity.HasKey(e => e.PlayerId).HasName("PK__PLAYERS__4A4E74A8557619E1");

            entity.Property(e => e.PlayerId).ValueGeneratedNever();
        });

        modelBuilder.Entity<PlayerMatchStat>(entity =>
        {
            entity.HasKey(e => e.StatId).HasName("PK__PLAYER_M__3A162D1EBC00C8F0");

            entity.Property(e => e.StatId).ValueGeneratedOnAdd();

            entity.HasOne(d => d.Match).WithMany(p => p.PlayerMatchStats)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PLAYER_MA__Match__7A672E12");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerMatchStats)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PLAYER_MA__Playe__7B5B524B");
        });

        modelBuilder.Entity<PlayerMatchStatsLedger>(entity =>
        {
            entity.ToView("PLAYER_MATCH_STATS_Ledger");
        });

        modelBuilder.Entity<PlayersLedger>(entity =>
        {
            entity.ToView("PLAYERS_Ledger");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
