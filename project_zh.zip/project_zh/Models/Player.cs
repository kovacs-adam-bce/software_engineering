﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace project_zh.Models;

[Table("PLAYERS")]
public partial class Player
{
    [Key]
    [Column("PlayerID")]
    public int PlayerId { get; set; }

    [StringLength(50)]
    public string FirstName { get; set; } = null!;

    [StringLength(50)]
    public string LastName { get; set; } = null!;

    [StringLength(50)]
    public string? Country { get; set; }

    [Column("ledger_start_transaction_id")]
    public long LedgerStartTransactionId { get; set; }

    [Column("ledger_end_transaction_id")]
    public long? LedgerEndTransactionId { get; set; }

    [Column("ledger_start_sequence_number")]
    public long LedgerStartSequenceNumber { get; set; }

    [Column("ledger_end_sequence_number")]
    public long? LedgerEndSequenceNumber { get; set; }

    [InverseProperty("Player1")]
    public virtual ICollection<Match> MatchPlayer1s { get; set; } = new List<Match>();

    [InverseProperty("Player2")]
    public virtual ICollection<Match> MatchPlayer2s { get; set; } = new List<Match>();

    [InverseProperty("Winner")]
    public virtual ICollection<Match> MatchWinners { get; set; } = new List<Match>();

    [InverseProperty("Player")]
    public virtual ICollection<PlayerMatchStat> PlayerMatchStats { get; set; } = new List<PlayerMatchStat>();
}
