﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace project_zh.Models;

[Table("PLAYER_MATCH_STATS")]
public partial class PlayerMatchStat
{
    [Key]
    [Column("StatID")]
    public int StatId { get; set; }

    [Column("MatchID")]
    public int MatchId { get; set; }

    [Column("PlayerID")]
    public int PlayerId { get; set; }

    [Column(TypeName = "decimal(5, 2)")]
    public decimal? ThreeDartAverage { get; set; }

    [Column(TypeName = "decimal(4, 1)")]
    public decimal? CheckoutPercentage { get; set; }

    public int? Total180s { get; set; }

    public int? LegsWon { get; set; }

    [ForeignKey("MatchId")]
    [InverseProperty("PlayerMatchStats")]
    public virtual Match Match { get; set; } = null!;

    [ForeignKey("PlayerId")]
    [InverseProperty("PlayerMatchStats")]
    public virtual Player Player { get; set; } = null!;
}
