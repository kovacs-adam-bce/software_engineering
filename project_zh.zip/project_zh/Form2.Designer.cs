﻿namespace project_zh
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            cmbPlayer1 = new ComboBox();
            cmbPlayer2 = new ComboBox();
            dtpDate = new DateTimePicker();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtAvg1 = new TextBox();
            label6 = new Label();
            numScore1 = new NumericUpDown();
            numScore2 = new NumericUpDown();
            label7 = new Label();
            txtAvg2 = new TextBox();
            txtVenue = new TextBox();
            label8 = new Label();
            btnOK = new Button();
            btnCancel = new Button();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)numScore1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numScore2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(72, 20);
            label1.TabIndex = 0;
            label1.Text = "1. Játékos";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 70);
            label2.Name = "label2";
            label2.Size = new Size(72, 20);
            label2.TabIndex = 1;
            label2.Text = "2. Játékos";
            // 
            // cmbPlayer1
            // 
            cmbPlayer1.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPlayer1.FormattingEnabled = true;
            cmbPlayer1.Location = new Point(12, 32);
            cmbPlayer1.Name = "cmbPlayer1";
            cmbPlayer1.Size = new Size(151, 28);
            cmbPlayer1.TabIndex = 2;
            // 
            // cmbPlayer2
            // 
            cmbPlayer2.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPlayer2.FormattingEnabled = true;
            cmbPlayer2.Location = new Point(12, 93);
            cmbPlayer2.Name = "cmbPlayer2";
            cmbPlayer2.Size = new Size(151, 28);
            cmbPlayer2.TabIndex = 3;
            // 
            // dtpDate
            // 
            dtpDate.Location = new Point(12, 158);
            dtpDate.Name = "dtpDate";
            dtpDate.Size = new Size(250, 27);
            dtpDate.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 135);
            label3.Name = "label3";
            label3.Size = new Size(127, 20);
            label3.TabIndex = 5;
            label3.Text = "Dátum megadása";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(410, 135);
            label4.Name = "label4";
            label4.Size = new Size(137, 20);
            label4.TabIndex = 6;
            label4.Text = "Helyszín megadása";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(411, 71);
            label5.Name = "label5";
            label5.Size = new Size(119, 20);
            label5.TabIndex = 7;
            label5.Text = "1. Játékos pontja";
            // 
            // txtAvg1
            // 
            txtAvg1.Location = new Point(410, 32);
            txtAvg1.Name = "txtAvg1";
            txtAvg1.Size = new Size(125, 27);
            txtAvg1.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(563, 71);
            label6.Name = "label6";
            label6.Size = new Size(119, 20);
            label6.TabIndex = 9;
            label6.Text = "2. Játékos pontja";
            // 
            // numScore1
            // 
            numScore1.Location = new Point(410, 94);
            numScore1.Name = "numScore1";
            numScore1.Size = new Size(150, 27);
            numScore1.TabIndex = 10;
            // 
            // numScore2
            // 
            numScore2.Location = new Point(563, 93);
            numScore2.Name = "numScore2";
            numScore2.Size = new Size(150, 27);
            numScore2.TabIndex = 11;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(410, 9);
            label7.Name = "label7";
            label7.Size = new Size(65, 20);
            label7.TabIndex = 12;
            label7.Text = "P1 Átlag";
            // 
            // txtAvg2
            // 
            txtAvg2.Location = new Point(563, 32);
            txtAvg2.Name = "txtAvg2";
            txtAvg2.Size = new Size(125, 27);
            txtAvg2.TabIndex = 13;
            // 
            // txtVenue
            // 
            txtVenue.Location = new Point(410, 158);
            txtVenue.Name = "txtVenue";
            txtVenue.Size = new Size(125, 27);
            txtVenue.TabIndex = 14;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(563, 9);
            label8.Name = "label8";
            label8.Size = new Size(65, 20);
            label8.TabIndex = 15;
            label8.Text = "P2 Átlag";
            // 
            // btnOK
            // 
            btnOK.DialogResult = DialogResult.OK;
            btnOK.Location = new Point(12, 212);
            btnOK.Name = "btnOK";
            btnOK.Size = new Size(375, 29);
            btnOK.TabIndex = 16;
            btnOK.Text = "Mentés";
            btnOK.UseVisualStyleBackColor = true;
            btnOK.Click += btnOK_Click;
            // 
            // btnCancel
            // 
            btnCancel.DialogResult = DialogResult.Cancel;
            btnCancel.Location = new Point(393, 212);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(395, 29);
            btnCancel.TabIndex = 17;
            btnCancel.Text = "Mégse";
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 258);
            Controls.Add(btnCancel);
            Controls.Add(btnOK);
            Controls.Add(label8);
            Controls.Add(txtVenue);
            Controls.Add(txtAvg2);
            Controls.Add(label7);
            Controls.Add(numScore2);
            Controls.Add(numScore1);
            Controls.Add(label6);
            Controls.Add(txtAvg1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(dtpDate);
            Controls.Add(cmbPlayer2);
            Controls.Add(cmbPlayer1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)numScore1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numScore2).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private ComboBox cmbPlayer1;
        private ComboBox cmbPlayer2;
        private DateTimePicker dtpDate;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtAvg1;
        private Label label6;
        private NumericUpDown numScore1;
        private NumericUpDown numScore2;
        private Label label7;
        private TextBox txtAvg2;
        private TextBox txtVenue;
        private Label label8;
        private Button btnOK;
        private Button btnCancel;
        private ErrorProvider errorProvider1;
    }
}