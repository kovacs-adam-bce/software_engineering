using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic.ApplicationServices;
using project_zh.Models;
using System.Windows.Forms;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace project_zh
{
    public partial class Form1 : Form
    {
        DartsDbContext context = new DartsDbContext();

        //UserControl1 uc1 = new UserControl1();
        //UserControl2 uc2 = new UserControl2();

        public Form1()
        {
            InitializeComponent();
        }

        private void ChangeContent(UserControl newContent)
        {
            panel2.Controls.Clear();
            newContent.Dock = DockStyle.Fill;
            panel2.Controls.Add(newContent);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserControl1 uc1 = new UserControl1();
            ChangeContent(uc1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserControl2 uc2 = new UserControl2();
            ChangeContent(uc2);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Biztosan ki szeretn�l l�pni?", "Kil�p�s", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();

            if (f2.ShowDialog() == DialogResult.OK)
            {
                button2_Click(sender, e);
            }
        }
    }
}