﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using project_zh.Models;

namespace project_zh
{
    public partial class Form2 : Form
    {
        DartsDbContext context = new DartsDbContext();

        public Form2()
        {
            InitializeComponent();

            LoadPlayers();

            txtVenue.TextChanged += ValidateForm;
            txtAvg1.TextChanged += ValidateForm;
            txtAvg2.TextChanged += ValidateForm;
            cmbPlayer1.SelectedIndexChanged += ValidateForm;
            cmbPlayer2.SelectedIndexChanged += ValidateForm;
        }
        private void Form2_Load(object sender, EventArgs e)
        {
        }

        private void LoadPlayers()
        {
            var players = context.Players.OrderBy(p => p.FirstName).ToList();

            cmbPlayer1.DataSource = new BindingList<Player>(players);
            cmbPlayer1.DisplayMember = "FirstName";
            cmbPlayer1.ValueMember = "PlayerId";

            cmbPlayer2.DataSource = new BindingList<Player>(players.ToList());
            cmbPlayer2.DisplayMember = "FirstName";
            cmbPlayer2.ValueMember = "PlayerId";
        }

        private void ValidateForm(object sender, EventArgs e)
        {
            bool isValid = true;
            errorProvider1.Clear();

            if (string.IsNullOrEmpty(txtVenue.Text))
            {
                errorProvider1.SetError(txtVenue, "A helyszín nem lehet üres!");
                isValid = false;
            }

            if (cmbPlayer1.SelectedValue != null && cmbPlayer2.SelectedValue != null)
            {
                if ((int)cmbPlayer1.SelectedValue == (int)cmbPlayer2.SelectedValue)
                {
                    errorProvider1.SetError(cmbPlayer2, "A két játékos nem lehet ugyanaz!");
                    isValid = false;
                }
            }

            Regex regexAvg = new Regex(@"^\d{1,3}(\.\d{1,2})?$");

            if (!regexAvg.IsMatch(txtAvg1.Text))
            {
                errorProvider1.SetError(txtAvg1, "Helyes formátum pl: 95.5 vagy 100");
                isValid = false;
            }
            if (!regexAvg.IsMatch(txtAvg2.Text))
            {
                errorProvider1.SetError(txtAvg2, "Helyes formátum pl: 95.5 vagy 100");
                isValid = false;
            }

            btnOK.Enabled = isValid;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                project_zh.Models.Match newMatch = new project_zh.Models.Match();

                // 1. MECCS ID GENERÁLÁS (Ez MARAD, mert itt nincs Identity)
                int nextMatchId = (context.Matches.Max(m => (int?)m.MatchId) ?? 0) + 1;
                newMatch.MatchId = nextMatchId;

                newMatch.MatchDate = DateOnly.FromDateTime(dtpDate.Value);
                newMatch.MatchVenue = txtVenue.Text;
                newMatch.Player1Id = (int)cmbPlayer1.SelectedValue;
                newMatch.Player2Id = (int)cmbPlayer2.SelectedValue;

                if (numScore1.Value > numScore2.Value)
                    newMatch.WinnerId = newMatch.Player1Id;
                else if (numScore2.Value > numScore1.Value)
                    newMatch.WinnerId = newMatch.Player2Id;

                context.Matches.Add(newMatch);

                // --- STATISZTIKÁK JAVÍTÁSA ---
                // NEM számolunk nextStatId-t! Hagyjuk, hogy az SQL szerver adja a számot.

                // 1. Játékos statisztikája
                PlayerMatchStat stat1 = new PlayerMatchStat();
                // stat1.StatId = ...; <--- EZT TÖRÖLTÜK!
                stat1.PlayerId = newMatch.Player1Id;
                stat1.MatchId = newMatch.MatchId;
                stat1.ThreeDartAverage = decimal.Parse(txtAvg1.Text.Replace(".", ","));
                stat1.LegsWon = (int)numScore1.Value;
                context.PlayerMatchStats.Add(stat1);

                // 2. Játékos statisztikája
                PlayerMatchStat stat2 = new PlayerMatchStat();
                // stat2.StatId = ...; <--- EZT IS TÖRÖLTÜK!
                stat2.PlayerId = newMatch.Player2Id;
                stat2.MatchId = newMatch.MatchId;
                stat2.ThreeDartAverage = decimal.Parse(txtAvg2.Text.Replace(".", ","));
                stat2.LegsWon = (int)numScore2.Value;
                context.PlayerMatchStats.Add(stat2);

                // -----------------------------

                context.SaveChanges();

                MessageBox.Show("Sikeres mentés!");
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba mentéskor: " + ex.Message +
                    (ex.InnerException != null ? "\n" + ex.InnerException.Message : ""));
                this.DialogResult = DialogResult.None;
            }
        }
    }
}